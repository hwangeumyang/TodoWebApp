package org.hgy.todospringweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoSpringWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoSpringWebApplication.class, args);
	}

}
